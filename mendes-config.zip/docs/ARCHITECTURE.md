Como o MCI funciona?
