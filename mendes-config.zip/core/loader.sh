#!/usr/bin/env bash

source lib/colors.sh
source lib/logger.sh

source core/constants.sh
source core/banner.sh

source lib/environment.sh
source lib/validation.sh